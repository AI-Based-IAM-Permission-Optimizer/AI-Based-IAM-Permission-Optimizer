class RecommendationController {
  /**
   * @param {import("../services/recommendation.service")} service - RecommendationService instance.
   */
  constructor(service) {
    if (!service) {
      throw new Error("RecommendationController requires a valid RecommendationService instance.");
    }
    this.service = service;
  }

  /**
   * GET /api/v1/recommendations
   */
  list = async (req, res, next) => {
    try {
      const { approval_status, recommendation, user_id, role_id, next_token } = req.query;
      const filters = { approval_status, recommendation, user_id, role_id, next_token };

      const result = await this.service.listRecommendations(filters);

      return res.status(200).json({
        count: result.data.length,
        data: result.data,
        next_token: result.next_token
      });
    } catch (error) {
      console.error(error); return next(error);
    }
  };

  /**
   * GET /api/v1/recommendations/:id
   */
  getById = async (req, res, next) => {
    try {
      const { id } = req.params;
      const item = await this.service.getRecommendationById(id);

      return res.status(200).json({
        data: item
      });
    } catch (error) {
      console.error(error); return next(error);
    }
  };

  /**
   * PATCH /api/v1/recommendations/:id/approve
   */
  approve = async (req, res, next) => {
    try {
      const { id } = req.params;
      const updated = await this.service.approveRecommendation(id, req.body);

      return res.status(200).json({
        message: "Recommendation approved successfully.",
        data: updated
      });
    } catch (error) {
      console.error(error); return next(error);
    }
  };

  /**
   * PATCH /api/v1/recommendations/:id/reject
   */
  reject = async (req, res, next) => {
    try {
      const { id } = req.params;
      const updated = await this.service.rejectRecommendation(id, req.body);

      return res.status(200).json({
        message: "Recommendation rejected successfully.",
        data: updated
      });
    } catch (error) {
      console.error(error); return next(error);
    }
  };

  /**
   * POST /api/v1/recommendations
   */
  ingestBatch = async (req, res, next) => {
    try {
      const result = await this.service.ingestRecommendationsBatch(req.body);
      return res.status(200).json(result);
    } catch (error) {
      console.error(error); return next(error);
    }
  };
}

module.exports = RecommendationController;
